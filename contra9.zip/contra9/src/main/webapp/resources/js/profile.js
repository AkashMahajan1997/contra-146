$(document).ready(function(){
    $("#edit").click(function(){

      
            $("#name").prop("disabled", false);
 			$("#age").prop("disabled", false);
			$("#date").prop("disabled", false);
			$("#phone").prop("disabled", false);
			$("#email").prop("disabled", false);
			$("#address").prop("disabled", false);
			$("#city").prop("disabled", false);
			$("#state").prop("disabled", false);
			$("#zipcode").prop("disabled", false);

  
      
    });
});