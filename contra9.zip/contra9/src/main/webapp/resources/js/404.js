window.onload = function(){
document.querySelector('.cont_principal').className= "cont_principal cont_error_active";  
  
}