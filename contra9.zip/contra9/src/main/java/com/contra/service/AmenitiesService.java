package com.contra.service;

import com.contra.entity.Amenities;

public interface AmenitiesService {
	void addAmenities (Amenities amenities,int contract_id);
	void deleteAmenities(int contract_id);
	Amenities getAmenity(int contract_id);
	void updateAmenities(Amenities amenities, int contract_id);
}
