package com.contra.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.contra.dao.TermDAO;
import com.contra.entity.Terms;

@Service("termService")
public class TermServiceImpl implements TermService {
	

	@Autowired
	private TermDAO termDAO;

	@Override
	public void addTerms(Terms terms,int contract_id) {
		terms.setContract_id(contract_id);
		termDAO.addTerm(terms);
	}

	@Override
	public void deleteTerms(int contract_id) {
		termDAO.deleteTerm(contract_id);
	}

	@Override
	public Terms getTerm(int contract_id) {
		Terms terms = termDAO.getTerm(contract_id);
		return terms;
	}

	@Override
	public void updateTerms(Terms terms, int contract_id) {
		terms.setContract_id(contract_id);
		termDAO.updateTerms(terms);		
	}	

}
