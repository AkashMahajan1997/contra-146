package com.contra.service;

import com.contra.entity.Terms;

public interface TermService {
	void addTerms(Terms terms,int contract_id);
	void deleteTerms(int contract_id);
	Terms getTerm(int contract_id);
	void updateTerms(Terms terms, int contract_id);
}
