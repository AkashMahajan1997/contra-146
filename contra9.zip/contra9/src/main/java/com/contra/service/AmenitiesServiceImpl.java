package com.contra.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.contra.dao.AmenitiesDAO;
import com.contra.entity.Amenities;

@Service("amenitiesService")
public class AmenitiesServiceImpl implements AmenitiesService {

	@Autowired
	private AmenitiesDAO amenitiesDAO;

	@Override
	public void addAmenities(Amenities amenities,int contract_id) {
		amenities.setContract_id(contract_id);
		amenitiesDAO.addAmenities(amenities);
	}

	@Override
	public void deleteAmenities(int contract_id) {
		amenitiesDAO.deleteAmenities(contract_id);
	}

	@Override
	public Amenities getAmenity(int contract_id) {
		Amenities amenities = amenitiesDAO.getAmenity(contract_id);
		return amenities;
	}

	@Override
	public void updateAmenities(Amenities amenities, int contract_id) {
		amenities.setContract_id(contract_id);
		amenitiesDAO.updateAmenities(amenities);
	}

}
