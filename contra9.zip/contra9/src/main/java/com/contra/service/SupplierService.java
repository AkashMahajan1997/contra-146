package com.contra.service;

import java.util.List;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;

public interface SupplierService {
	
	void addSupplier(Supplier supplier);
	void updateSupplier(Supplier supplier);
	List<Contract> getAllContract();
	String getUsername();
	Supplier getUser(String email);
	void updateProfile(Supplier supplier);
	
}
