package com.contra.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import org.springframework.security.core.userdetails.UserDetails;
import com.contra.dao.ContractDAO;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
@Service("contactService")
public class ContractServiceImp implements ContractService{
	
	@Autowired
	private ContractDAO contractDAO;
	
	@Override
	public void addContract(Contract contract) {
		String email;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		email = ((UserDetails) principal).getUsername();
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		Supplier supplier = contractDAO.findSupplierByEmail(email);
		String supplier_id = supplier.getSupplier_id();
		contract.setSupplier_id(supplier_id);
		contract.setSub_date(dateFormat.format(date));
		contract.setPro_date(" ");
		contract.setStatus("Pending");
		contractDAO.addContract(contract);
	}

	@Override
	public void deleteContract(int id) {
		contractDAO.deleteContract(id);
	}

	@Override
	public void updateContract(Contract contract) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		contract.setSub_date(dateFormat.format(date));
		contract.setPro_date(" ");
		contract.setStatus("Pending");
		contractDAO.updateContract(contract);
	}
	
	@Override
	public List<Contract> getAllContracts() {
		String email;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			email = ((UserDetails)principal).getUsername();
		} else {
			email = principal.toString();
		}
		Supplier supplier=contractDAO.findSupplierByEmail(email);
		String supplier_id=supplier.getSupplier_id();
		List<Contract> list = contractDAO.getAllContracts(supplier_id);
		return list;
	}

	@Override
	public List<Contract> getAllPendingContract() {
		String email;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			email = ((UserDetails)principal).getUsername();
		} else {
			email = principal.toString();
		}
		Supplier supplier=contractDAO.findSupplierByEmail(email);
		String supplier_id=supplier.getSupplier_id();
		List<Contract> list = contractDAO.getAllPendingContract(email,supplier_id);
		return list;
	}
	
	@Override
	public List<Contract> getAllAcceptedContract() {
		String email;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			email = ((UserDetails)principal).getUsername();
		} else {
			email = principal.toString();
		}
		Supplier supplier=contractDAO.findSupplierByEmail(email);
		String supplier_id=supplier.getSupplier_id();
		List<Contract> list = contractDAO.getAllAcceptedContract(email,supplier_id);
		return list;
	}

	@Override
	public Contract getContract(int contract_id) {
		Contract contract = contractDAO.getContract(contract_id);
		return contract;
	}
}
