package com.contra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.contra.dao.SupplierDAO;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Supplier_ID;

@Service("supplierService")
public class SupplierServiceImpl implements SupplierService {

	@Autowired
	private SupplierDAO supplierDAO;
	
	@Override
	public String getUsername() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		} else {
			username = principal.toString();
		}
		return username;
	}
	
	@Override
	public Supplier getUser(String email) {
		Supplier supplier = supplierDAO.getUser(email);
		return supplier;
	}
	
	@Override
	public void updateSupplier(Supplier supplier) {
		supplierDAO.updateSupplier(supplier);
	}

	@Override
	public List<Contract> getAllContract() {
		String email;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			email = ((UserDetails)principal).getUsername();
		} else {
			email = principal.toString();
		}
		List<Contract> list = supplierDAO.getAllContract(email);
		return list;
	}

	@Override
	public void addSupplier(Supplier supplier) {
		String prefix = "SP_";
		Supplier_ID supplier_id = new Supplier_ID();
		int id = supplierDAO.getLastSupplier(supplier_id);
		int temp = id, count = 0;
		while (temp > 0) {
			count++;
			temp /= 10;
		}
		for (temp = 0; temp + count < 7; temp++) {
			prefix += "0";
		}
		if (count != 0)
			prefix += id;
		supplier.setSupplier_id(prefix);
		supplier.setStatus("Pending");
		supplierDAO.addSupplier(supplier);
	}

	@Override
	public void updateProfile(Supplier supplier) {
		supplierDAO.updateSupplier(supplier);		
	}

}
