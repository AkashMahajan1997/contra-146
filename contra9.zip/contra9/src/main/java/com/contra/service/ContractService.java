package com.contra.service;

import java.util.List;

import com.contra.entity.Contract;

public interface ContractService {
	void addContract(Contract contract);
	void deleteContract(int id);	
	void updateContract(Contract contract);
	List<Contract> getAllContracts();
	List<Contract> getAllAcceptedContract();
	List<Contract> getAllPendingContract();
	Contract getContract(int contract_id);
}
