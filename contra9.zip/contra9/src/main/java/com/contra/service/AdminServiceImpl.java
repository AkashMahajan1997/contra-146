package com.contra.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import com.contra.dao.AdminDAO;
import com.contra.entity.Admin;
import com.contra.entity.Admin_ID;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.User;

@Service("adminService")
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminDAO adminDAO;
	
	@Override
	public Admin getUser(String username) {
		Admin admin = adminDAO.getUser(username);
		return admin;
	}
	
	@Override
	public String getUsername() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		} else {
			username = principal.toString();
		}
		return username;
	}
	
	@Override
	public void updateProfile(Admin admin) {
		adminDAO.updateAdmin(admin);
	}
	
	@Override
	public void addAdmin(Admin admin) {
		String prefix = "AD_";
		Admin_ID admin_id = new Admin_ID();
		int id = adminDAO.getLastAdmin(admin_id);
		int temp = id, count = 0;
		while (temp > 0) {
			count++;
			temp /= 10;
		}
		for (temp = 0; temp + count < 7; temp++) {
			prefix += "0";
		}
		if (count != 0)
			prefix += id;
		admin.setAdmin_id(prefix);
		adminDAO.addAdmin(admin);
	}
	
	@Override
	public List<Contract> getAllContracts() {
		List<Contract> list = adminDAO.getAllContracts();
		return list;
	}
	
	@Override
	public List<Contract> getPendingContracts() {
		List<Contract> list = adminDAO.getPendingContracts();
		return list;
	}

	@Override
	public Contract getContract(int contract_id) {
		Contract contract = adminDAO.getContract(contract_id);
		return contract;
	}
	
	@Override
	public void updateStatusOfContract(int contract_id, String status) {
		if(status.equals("Accept")){
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			Date date = new Date();
			String pro_date = dateFormat.format(date);
			adminDAO.updateStatusOfContract(contract_id, pro_date,status);
		}			
		else if(status.equals("Reject"))
			adminDAO.deleteContract(contract_id);
	}

	@Override
	public List<Supplier> getAllSupplier() {
		List<Supplier> list=adminDAO.getAllSupplier();
		return list;
	}
	
	@Override
	public List<Supplier> getPendingSuppliers() {
		List<Supplier> list = adminDAO.getPendingSuppliers();
		return list;
	}
	
	@Override
	public Supplier getSupplier(String id) {
		Supplier supplier = adminDAO.getSupplier(id);
		return supplier;
	}
	
	@Override
	public void updateStatusOfSupplier(String supplier_id, String status) {
		if(status.equals("Accept")){
			adminDAO.updateStatusOfSupplier(supplier_id, status);
			Supplier supplier = adminDAO.getSupplier(supplier_id);
			User user = new User(supplier.getEmail_id(), supplier.getPassword(), "ROLE_SUPPLIER");
			adminDAO.addUser(user);
		}			
		else if(status.equals("Reject"))
			adminDAO.deleteSupplier(supplier_id);
	}

}
