package com.contra.service;

import java.util.List;

import com.contra.entity.Admin;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;

public interface AdminService {
	
	void addAdmin(Admin admin);
	List<Contract> getAllContracts();
	List<Contract> getPendingContracts();
	Contract getContract(int contract_id);
	void updateStatusOfContract(int contract_id,String status);
	List<Supplier> getAllSupplier();
	List<Supplier> getPendingSuppliers();
	Supplier getSupplier(String id);
	void updateStatusOfSupplier(String supplier_id, String status);
	String getUsername();
	Admin getUser(String username);
	void updateProfile(Admin admin);

}
