package com.contra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="admin_table")
public class Admin {
	
	@Id
	@Column(name="admin_id", length=10)
	private String admin_id;

	@NotNull
	@Column(name="first_name",length=50)
	private String first_name;
	
	@NotNull
	@Column(name="password",length=100)
	private String password;
	
	@NotNull
	@Column(name="last_name",length=50)
	private String last_name;
	
	@NotNull
	@Column(name="age", length=2)
	private int age;
	
	@NotNull
	@Column(name="gender", length=10)
	private String gender;
	
	@NotNull
	@Column(name="dob", length=10)
	private String dob;
	
	@NotNull
	@Column(name="number", length=10)
	private String contact_number;
	
	@Column(name="alt_number", length=10)
	private String alt_number;
	
	@NotNull
	@Column(name="email_id", length=50)
	private String email_id;
	
	
	public Admin(String admin_id, String first_name, String last_name, int age, String gender, String dob, 
			String contact_number,String alt_number, String email_id, String password) {
		this.admin_id = admin_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.age = age;
		this.gender = gender;
		this.dob = dob;
		this.contact_number = contact_number;
		this.alt_number = alt_number;
		this.email_id = email_id;
		this.password=password;
	}
	
	public Admin(String admin_id, String first_name, String last_name, String email_id) {
		this.admin_id = admin_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email_id = email_id;
	}

	public Admin() {
		
	}
	
	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public String getContact_number() {
		return contact_number;
	}
	
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	
	public String getAlt_number() {
		return alt_number;
	}

	public void setAlt_number(String alt_number) {
		this.alt_number = alt_number;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	@Override
	public String toString() {
		return "Admin [admin_id=" + admin_id + ", first_name=" + first_name + ", last_name=" + last_name + ", age="
				+ age + ", gender=" + gender + ", dob=" + dob + ", contact_number=" + contact_number + ", alt_number="
				+ alt_number + ", email_id=" + email_id + "]";
	}
	
}
