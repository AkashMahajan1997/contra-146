package com.contra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;



@Entity
@Table(name="contract_table")
public class Contract {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="contract_id", length=10)
	private int contract_id;
	
	@NotNull
	@Column(name="description",length=200)
	private String desc;
	
	@NotNull
	@Column(name="submission_date",length=10)
	private String sub_date;
	
	@NotNull
	@Column(name="processing_date",length=10)
	private String pro_date;
	
	@NotNull
	@Column(name="status",length=10)
	private String status;
	
	@NotNull
	@Column(name="supplier_id",length = 10)
	private String supplier_id;
	
	
	public Contract(int contract_id, String desc, String sub_date, String pro_date, String status, 
			String supplier_id) {
		this.contract_id = contract_id;
		this.desc = desc;
		this.sub_date = sub_date;
		this.pro_date = pro_date;
		this.status = status;
		this.supplier_id = supplier_id;
	}

	public Contract() {
		
	}

	public int getContract_id() {
		return contract_id;
	}

	public void setContract_id(int contract_id) {
		this.contract_id = contract_id;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getSub_date() {
		return sub_date;
	}

	public void setSub_date(String sub_date) {
		this.sub_date = sub_date;
	}

	public String getPro_date() {
		return pro_date;
	}

	public void setPro_date(String pro_date) {
		this.pro_date = pro_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSupplier_id() {
		return supplier_id;
	}

	public void setSupplier_id(String supplier_id) {
		this.supplier_id = supplier_id;
	}

	@Override
	public String toString() {
		return "Contract [contract_id=" + contract_id + ", desc=" + desc + ", sub_date=" + sub_date + ", pro_date="
				+ pro_date + ", status=" + status + ", supplier_id=" + supplier_id + "]";
	}

}
