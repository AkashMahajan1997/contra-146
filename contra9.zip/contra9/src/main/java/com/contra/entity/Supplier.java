package com.contra.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="supplier_table")
public class Supplier{
	
	@Id
	@Column(name="Supplier_ID",length = 10)
	private String supplier_id;
	
	@NotNull
	@Column(name="first_name",length=50)
	private String first_name;
	
	@NotNull
	@Column(name="last_name",length=50)
	private String last_name;
	
	@NotNull
	@Column(name="age", length=2)
	private int age;
	
	@Column(name="gender", length=10)
	private String gender;
	
	@Column(name="dob", length=10)
	private String dob;
	
	@NotNull
	@Column(name="number", length=10)
	private String contact_number;
	
	@Column(name="alt_number", length=10)
	private String alt_number;
	
	@NotNull
	@Column(name="email_id", length=50, unique=true)
	private String email_id;
	
	@NotNull
	@Column(name="password", length=100)
	private String password;
	
	@NotNull
	@Column(name="Address_l1", length=100)
	private String address_1;
	
	@NotNull
	@Column(name="Address_l2",length=100)
	private String address_2;
	
	@NotNull
	@Column(name="City",length=50)
	private String city;
	
	@NotNull
	@Column(name="State",length=50)
	private String state;
	
	@NotNull
	@Column(name="zip",length=10)
	private int zip;
	
	@NotNull
	@Column(name="status",length=10)
	private String status;

	@OneToMany(fetch=FetchType.EAGER, mappedBy="supplier_id", cascade=CascadeType.ALL)
	private List<Contract> contract_list;

	public Supplier() {
		
	}

	public Supplier(String supplier_id, String first_name, String last_name, int age, String gender, String dob, String contact_number,
			String alt_number, String email_id, String password, String address_1, String address_2, String city,
			String state, int zip, List<Contract> contract_list,String status) {
		this.supplier_id = supplier_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.age = age;
		this.gender = gender;
		this.dob = dob;
		this.contact_number = contact_number;
		this.alt_number = alt_number;
		this.email_id = email_id;
		this.password = password;
		this.address_1 = address_1;
		this.address_2 = address_2;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.contract_list=contract_list;
		this.status=status;
	}

	public List<Contract> getContract_list() {
		return contract_list;
	}

	public void setContract_list(List<Contract> contract_list) {
		this.contract_list = contract_list;
	}

	public String getSupplier_id() {
		return supplier_id;
	}

	public void setSupplier_id(String supplier_id) {
		this.supplier_id = supplier_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public String getAlt_number() {
		return alt_number;
	}

	public void setAlt_number(String alt_number) {
		this.alt_number = alt_number;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress_1() {
		return address_1;
	}

	public void setAddress_1(String address_1) {
		this.address_1 = address_1;
	}

	public String getAddress_2() {
		return address_2;
	}

	public void setAddress_2(String address_2) {
		this.address_2 = address_2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Supplier [supplier_id=" + supplier_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", age=" + age + ", gender=" + gender + ", dob=" + dob + ", contact_number=" + contact_number
				+ ", alt_number=" + alt_number + ", email_id=" + email_id + ", password=" + password + ", address_1="
				+ address_1 + ", address_2=" + address_2 + ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", status=" + status + "]";
	}
	
}
