package com.contra.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "amenities")
public class Amenities {

	@Id
	@Column(name="contract_id",length = 10)
	private int contract_id;
	
	@NotNull
	@Column(name = "amenities1",length = 100)
	private String amenities1;
	
	@Column(name = "amenities2",length = 100)
	private String amenities2;
	
	@Column(name = "amenities3",length = 100)
	private String amenities3;
	
	@Column(name = "amenities4",length = 100)
	private String amenities4;
	
	@Column(name = "amenities5",length = 100)
	private String amenities5;
	
	@Column(name = "other_info",length=200)
	private String a_other_info;
	
	public Amenities(int contract_id, String amenities1, String amenities2, String amenities3, String amenities4,
			String amenities5, String a_other_info) {
		this.contract_id = contract_id;
		this.amenities1 = amenities1;
		this.amenities2 = amenities2;
		this.amenities3 = amenities3;
		this.amenities4 = amenities4;
		this.amenities5 = amenities5;
		this.a_other_info = a_other_info;
	}

	public Amenities() {
		
	}

	public int getContract_id() {
		return contract_id;
	}

	public void setContract_id(int contract_id) {
		this.contract_id = contract_id;
	}

	public String getAmenities1() {
		return amenities1;
	}

	public void setAmenities1(String amenities1) {
		this.amenities1 = amenities1;
	}

	public String getAmenities2() {
		return amenities2;
	}

	public void setAmenities2(String amenities2) {
		this.amenities2 = amenities2;
	}

	public String getAmenities3() {
		return amenities3;
	}

	public void setAmenities3(String amenities3) {
		this.amenities3 = amenities3;
	}

	public String getAmenities4() {
		return amenities4;
	}

	public void setAmenities4(String amenities4) {
		this.amenities4 = amenities4;
	}

	public String getAmenities5() {
		return amenities5;
	}

	public void setAmenities5(String amenities5) {
		this.amenities5 = amenities5;
	}

	public String getA_other_info() {
		return a_other_info;
	}

	public void setA_other_info(String a_other_info) {
		this.a_other_info = a_other_info;
	}

	@Override
	public String toString() {
		return "Amenities [contract_id=" + contract_id + ", amenities1=" + amenities1 + ", amenities2=" + amenities2
				+ ", amenities3=" + amenities3 + ", amenities4=" + amenities4 + ", amenities5=" + amenities5
				+ ", other_info=" + a_other_info + "]";
	}

}
