package com.contra.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.Admin;
import com.contra.entity.Admin_ID;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.User;

@Repository("adminDAO")
public class AdminDAOImpl implements AdminDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Admin getUser(String username) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Admin where email_id = :one ";
		Query<Admin> query = session.createQuery(hql);
		query.setParameter("one", username);
		List<Admin> list = query.getResultList();
		return list.get(0);
	}

	@Override
	@Transactional
	public void addAdmin(Admin admin) {
		Session session = sessionFactory.getCurrentSession();
		admin.setPassword(passwordEncoder.encode(admin.getPassword()));
		User user = new User(admin.getEmail_id(), admin.getPassword(), "ROLE_ADMIN");
		session.save(admin);
		session.save(user);

	}
	
	@Override
	@Transactional
	public int getLastAdmin(Admin_ID admin_id) {
		Session session = sessionFactory.getCurrentSession();
		session.save(admin_id);
		int sr_no = admin_id.getSr_no();
		return sr_no;
	}
	
	@Override
	@Transactional
	public List<Contract> getAllContracts() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Contract> criteriaQuery = criteriaBuilder.createQuery(Contract.class);
		Root<Contract> root = criteriaQuery.from(Contract.class);
		criteriaQuery.select(root);
		Query<Contract> query = session.createQuery(criteriaQuery);
		List<Contract> list = query.getResultList();
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Contract> getPendingContracts() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "FROM Contract C WHERE C.status='Pending'";
		Query<Contract> query = session.createQuery(hql);
		List<Contract> list = query.getResultList();
		return list;
	}

	@Override
	@Transactional
	public Contract getContract(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Contract contract = session.get(Contract.class, contract_id);
		return contract;
	}

	@Override
	@Transactional
	public void updateStatusOfContract(int contract_id,String pro_date, String status) {
		Session session = sessionFactory.getCurrentSession();
		Query<?> query = session.createQuery("update Contract set status= :one , pro_date= :three " + "where contract_id= :two");
		query.setParameter("one", status);
		query.setParameter("three", pro_date);
		query.setParameter("two", contract_id);
		query.executeUpdate();
	}

	@Override
	@Transactional
	public void deleteContract(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Contract contract = session.byId(Contract.class).load(contract_id);
		session.delete(contract);
	}

	@Override
	@Transactional
	public List<Supplier> getAllSupplier() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Supplier> criteriaQuery = criteriaBuilder.createQuery(Supplier.class);
		Root<Supplier> root = criteriaQuery.from(Supplier.class);
		criteriaQuery.select(root);
		Query<Supplier> query = session.createQuery(criteriaQuery);
		List<Supplier> list = query.getResultList();
		return list;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Supplier> getPendingSuppliers() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "FROM Supplier C WHERE C.status='Pending'";
		Query<Supplier> query = session.createQuery(hql);
		List<Supplier> list = query.getResultList();
		return list;
	}

	@Override
	@Transactional
	public Supplier getSupplier(String supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		Supplier supplier = session.get(Supplier.class, supplier_id);
		return supplier;
	}
	
	@Override
	@Transactional
	public void addUser(User user){
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}
	
	@Override
	@Transactional
	public void updateStatusOfSupplier(String supplier_id,String status) {
		Session session = sessionFactory.getCurrentSession();
		Query<?> query = session.createQuery("update Supplier set status= :one " + "where supplier_id= :two");
		query.setParameter("one", status);
		query.setParameter("two", supplier_id);
		query.executeUpdate();
	}

	@Override
	@Transactional
	public void deleteSupplier(String supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		Supplier supplier = session.byId(Supplier.class).load(supplier_id);
		session.delete(supplier);
	}

	@Override
	@Transactional
	public void updateAdmin(Admin admin) {
		Session session = sessionFactory.getCurrentSession();
		session.update(admin);
	}

}
