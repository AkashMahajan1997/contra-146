package com.contra.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;

@Repository("contractDAO")
public class ContractDAOImpl implements ContractDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public void addContract(Contract contract) {
		Session session = sessionFactory.getCurrentSession();
		session.save(contract);
	}

	@Override
	@Transactional
	public void deleteContract(int id) {
		Session session = sessionFactory.getCurrentSession();
		Contract contract = session.get(Contract.class, id);
		session.delete(contract);
	}

	@Override
	@Transactional
	public void updateContract(Contract contract) {
		Session session = sessionFactory.getCurrentSession();
		session.update(contract);
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Supplier findSupplierByEmail(String email) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Supplier where email_id=?";
		Query<Supplier> query = session.createQuery(hql);
		query.setParameter(0, email);
		List<Supplier> supplier = query.getResultList();
		if (supplier.size() > 0) {
			return supplier.get(0);
		} else {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Contract> getAllContracts(String supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Contract c where c.supplier_id = :supplier_id";
		Query<Contract> query = session.createQuery(hql);
		query.setParameter("supplier_id", supplier_id);
		List<Contract> list = query.getResultList();
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Contract> getAllPendingContract(String email,String supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Contract c where c.supplier_id = :supplier_id and c.status = 'Pending'";
		Query<Contract> query = session.createQuery(hql);
		query.setParameter("supplier_id", supplier_id);
		List<Contract> list = query.getResultList();	
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<Contract> getAllAcceptedContract(String email,String supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Contract c where c.supplier_id = :supplier_id and c.status = 'Accept'";
		Query<Contract> query = session.createQuery(hql);
		query.setParameter("supplier_id",supplier_id);
		List<Contract> list = query.list();
		return list;
	}

	@Override
	@Transactional
	public Contract getContract(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Contract contract = session.byId(Contract.class).load(contract_id);
		return contract;
	}	
}
