package com.contra.dao;

import com.contra.entity.User;

public interface UserDAO {
User findUserByUserName(String name); 
}
