package com.contra.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Terms;

@Repository("TermDAO")
public class TermDAOImpl implements TermDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public void addTerm(Terms terms) {
		Session session = sessionFactory.getCurrentSession();
		session.save(terms);
	}

	@Override
	@Transactional
	public void deleteTerm(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Terms terms = session.byId(Terms.class).load(contract_id);
		session.delete(terms);
	}

	@Override
	@Transactional
	public Contract getLastContract(String id) {
		Supplier supplier = findSupplierByEmail(id);
		List<Contract> list = supplier.getContract_list();
		return list.get(list.size() - 1);
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Supplier findSupplierByEmail(String email) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Supplier where email_id=?";
		Query<Supplier> query = session.createQuery(hql);
		query.setParameter(0, email);
		List<Supplier> supplier = query.getResultList();
		if (supplier.size() > 0) {
			return supplier.get(0);
		} else {
			return null;
		}
	}

	@Override
	@Transactional
	public Terms getTerm(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Terms terms = session.byId(Terms.class).load(contract_id);
		return terms;
	}

	@Override
	@Transactional
	public void updateTerms(Terms terms) {
		Session session = sessionFactory.getCurrentSession();
		session.update(terms);		
	}

}
