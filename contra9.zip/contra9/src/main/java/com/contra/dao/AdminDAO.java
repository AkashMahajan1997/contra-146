package com.contra.dao;

import java.util.List;

import com.contra.entity.Admin;
import com.contra.entity.Admin_ID;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.User;

public interface AdminDAO {

	Contract getContract(int contract_id);
	List<Contract> getAllContracts();
	List<Supplier> getAllSupplier();
	void updateStatusOfSupplier(String supplier_id,String status);
	void addAdmin(Admin admin);
	void updateStatusOfContract(int contract_id,String pro_date,String status);
	int getLastAdmin(Admin_ID admin_id);
	List<Contract> getPendingContracts();
	void deleteContract(int contract_id);
	List<Supplier> getPendingSuppliers();
	Supplier getSupplier(String id);
	void deleteSupplier(String supplier_id);
	Admin getUser(String username);
	void addUser(User user);
	void updateAdmin(Admin admin);
	
}
