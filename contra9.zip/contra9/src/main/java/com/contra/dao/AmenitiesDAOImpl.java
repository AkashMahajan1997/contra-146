package com.contra.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.Amenities;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;

@Repository("amemitiesDAO")
public class AmenitiesDAOImpl implements AmenitiesDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public void addAmenities (Amenities amenities) {
		Session session=sessionFactory.getCurrentSession();
		session.save(amenities);
	}

	@Override
	@Transactional
	public void deleteAmenities(int contract_id) {
		Session session=sessionFactory.getCurrentSession();
		Amenities amenities = session.byId(Amenities.class).load(contract_id);
		session.delete(amenities);
	}

	@Override
	@Transactional
	public Contract getLastContract(String email) {
		Supplier supplier = findSupplierByEmail(email);
		List<Contract> list = supplier.getContract_list();
		return list.get(list.size() - 1);
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Supplier findSupplierByEmail(String email) {
		Session session = sessionFactory.getCurrentSession();
		String hql= "from Supplier where email_id=?";
		Query<Supplier> query = session.createQuery(hql);
		query.setParameter(0, email);
		List<Supplier> supplier = query.getResultList();
		if (supplier.size() > 0) {
			return supplier.get(0);
		} else {
			return null;
		}
	}

	@Override
	@Transactional
	public Amenities getAmenity(int contract_id) {
		Session session = sessionFactory.getCurrentSession();
		Amenities amenities = session.byId(Amenities.class).load(contract_id);
		return amenities;
	}

	@Override
	@Transactional
	public void updateAmenities(Amenities amenities) {
		Session session=sessionFactory.getCurrentSession();
		session.update(amenities);
	}
}
