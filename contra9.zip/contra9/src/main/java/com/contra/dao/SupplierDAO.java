package com.contra.dao;

import java.util.List;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Supplier_ID;

public interface SupplierDAO {
	void addSupplier(Supplier  supplier);
	void updateSupplier(Supplier supplier);
	List<Contract> getAllContract(String id);
	int getLastSupplier(Supplier_ID supplier_id);	
	Supplier fingSupplierByEmail(String email); 
	Supplier getUser(String email); 
	
}
