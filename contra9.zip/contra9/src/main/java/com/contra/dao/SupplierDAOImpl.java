package com.contra.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Supplier_ID;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	@Transactional
	public void addSupplier(Supplier supplier){
		Session session = sessionFactory.getCurrentSession();
		supplier.setPassword(passwordEncoder.encode(supplier.getPassword()));
		session.save(supplier);
	}

	@Override
	@Transactional
	public void updateSupplier(Supplier supplier) {
		Session session = sessionFactory.getCurrentSession();
		session.update(supplier);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Supplier getUser(String email) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Supplier where email_id = :one ";
		Query<Supplier> query = session.createQuery(hql);
		query.setParameter("one", email);
		List<Supplier> list = query.getResultList();
		if(!list.isEmpty())
			return list.get(0);
		else
			return null;
	}

	@Override
	@Transactional
	public List<Contract> getAllContract(String email) {
		Supplier supplier = fingSupplierByEmail(email);
		List<Contract> list = supplier.getContract_list();
		return list;
	}

	@Override
	@Transactional
	public int getLastSupplier(Supplier_ID supplier_id) {
		Session session = sessionFactory.getCurrentSession();
		session.save(supplier_id);
		int sr_no = supplier_id.getSr_no();
		return sr_no;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public Supplier fingSupplierByEmail(String email) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Supplier where email_id=?";
		Query<Supplier> query = session.createQuery(hql);
		query.setParameter(0, email);
		List<Supplier> supplier = query.getResultList();
		if (supplier.size() > 0) {
			return supplier.get(0);
		} else {
			return null;
		}
	}
}
