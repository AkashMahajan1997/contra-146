package com.contra.dao;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Terms;

public interface TermDAO {
	void addTerm(Terms terms);
	void deleteTerm(int contract_id);
	public Contract getLastContract(String id);
	public Supplier findSupplierByEmail(String email);
	Terms getTerm(int contract_id);
	void updateTerms(Terms terms);
}
