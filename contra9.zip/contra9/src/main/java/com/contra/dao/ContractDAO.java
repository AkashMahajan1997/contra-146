package com.contra.dao;

import java.util.List;

import com.contra.entity.Contract;
import com.contra.entity.Supplier;

public interface ContractDAO {
	void addContract(Contract contract);
	void deleteContract(int id);	
	void updateContract(Contract contract);
	Supplier findSupplierByEmail(String email);
	List<Contract> getAllContracts(String supplier_id);
	List<Contract> getAllPendingContract(String email,String supplier_id);
	List<Contract> getAllAcceptedContract(String email,String supplier_id);
	Contract getContract(int contract_id);
}
