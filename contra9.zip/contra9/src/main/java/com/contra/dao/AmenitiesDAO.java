package com.contra.dao;

import com.contra.entity.Amenities;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;

public interface AmenitiesDAO {
	void addAmenities (Amenities amenities);
	void deleteAmenities(int contract_id);
	public Contract getLastContract(String id);
	public Supplier findSupplierByEmail(String email);
	Amenities getAmenity(int contract_id);
	void updateAmenities(Amenities amenities);
}
