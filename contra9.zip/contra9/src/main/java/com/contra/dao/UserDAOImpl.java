package com.contra.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.contra.entity.User;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@SuppressWarnings("unchecked")
	@Transactional
	public User findUserByUserName(String name) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from User where username=?";
		Query<User> query = session.createQuery(hql);
		query.setParameter(0, name);
		List<User> users = query.getResultList();
		if (users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}
	}
}
