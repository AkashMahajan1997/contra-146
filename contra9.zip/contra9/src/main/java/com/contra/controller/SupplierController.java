package com.contra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.contra.entity.Supplier;
import com.contra.entity.Contract;
import com.contra.service.SupplierService;

@Controller
@RequestMapping("/supplier")
public class SupplierController {

	@Autowired
	private SupplierService supplierService;
	
	private Supplier supplier=null;
	
	@GetMapping("/home")
	public String homePage(Model model) {
		if(supplier==null){
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}		
		model.addAttribute("admin", supplier.getFirst_name()+" "+supplier.getLast_name());
		return "supplierHome";
	}
	
	@GetMapping("/listContract")
	public String displayAllContract(Model model){
		List<Contract> list=supplierService.getAllContract();
		if(supplier==null){
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}		
		model.addAttribute("admin", supplier.getFirst_name()+" "+supplier.getLast_name());
		model.addAttribute("contracts",list);		
		return "listContractSupplier";
	}
	
	@GetMapping("/profile")
	public String showProfile(Model model)
	{	
		if(supplier==null){
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("supplier", supplier);
		model.addAttribute("admin", supplier.getFirst_name()+" "+supplier.getLast_name());
		return "profileSupplier";
	}
	
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute("supplier") Supplier supplier){
		System.out.println(supplier.toString());
		this.supplier = supplier;
		supplierService.updateProfile(supplier);
		return "redirect:/supplier/profile";
	}
	
	@GetMapping("/about")
	public String aboutPage(Model model){
		if(supplier==null){
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name()+" "+supplier.getLast_name());
		return "aboutSupplier";
	}

}

