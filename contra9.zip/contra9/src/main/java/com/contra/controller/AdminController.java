package com.contra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.contra.entity.Admin;
import com.contra.entity.Amenities;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Terms;
import com.contra.service.AdminService;
import com.contra.service.AmenitiesService;
import com.contra.service.ContractService;
import com.contra.service.TermService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ContractService contractService;

	@Autowired
	private TermService termService;

	@Autowired
	private AmenitiesService amenitiesService;
	
	private Admin admin=null;
	
	@GetMapping("/home")
	public String homePage(Model model) {
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "adminHome";
	}
	
	@GetMapping("/profile")
	public String profilePage(Model model){
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin1",admin);
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "profileAdmin";
	}
	
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute("admin1") Admin admin){
		this.admin = admin;
		adminService.updateProfile(admin);
		return "redirect:/admin/profile";
	}
	
	@GetMapping("/about")
	public String aboutPage(Model model){
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "aboutAdmin";
	}
	
	@GetMapping("/all/contract")
	public String getAllContracts(Model model) {
		List<Contract> list = adminService.getAllContracts();
		model.addAttribute("contracts", list);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "listContractAdmin";
	}
	
	@GetMapping("/pending/contract")
	public String pending_contract(Model model) {
		List<Contract> list = adminService.getPendingContracts();
		model.addAttribute("contracts", list);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "pendingContractAdmin";
	}

	@GetMapping("/view/contract")
	public String getContract(@RequestParam("contract_id") int contract_id, Model model) {
		Contract contract = contractService.getContract(contract_id);
		Terms terms = termService.getTerm(contract_id);
		Amenities amenities = amenitiesService.getAmenity(contract_id);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		model.addAttribute("contract", contract);
		model.addAttribute("terms", terms);
		model.addAttribute("amenities", amenities);
		
		return "viewContractAdmin";
	}

	@GetMapping("/update/contract")
	public String updateContractStatus(@RequestParam("contract_id") int contract_id, @RequestParam("status") String status) {
		adminService.updateStatusOfContract(contract_id, status);
		return "redirect:/admin/pending/contract";
	}

	@GetMapping("/all/supplier")
	public String displayAllsuppliers(Model model) {
		List<Supplier> list = adminService.getAllSupplier();
		model.addAttribute("suppliers", list);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "listSupplier";
	}
	
	@GetMapping("/pending/supplier")
	public String pending_supplier(Model model) {
		List<Supplier> list = adminService.getPendingSuppliers();
		model.addAttribute("suppliers", list);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "pendingSupplier";
	}

	@GetMapping("/view/supplier")
	public String getSupplier(@RequestParam("supplier_id") String supplier_id, Model model) {
		Supplier supplier = adminService.getSupplier(supplier_id);
		model.addAttribute("supplier", supplier);
		if(admin==null){
			String username = adminService.getUsername();
			admin = adminService.getUser(username);
		}
		model.addAttribute("supplier", supplier);
		model.addAttribute("admin", admin.getFirst_name()+" "+admin.getLast_name());
		return "viewSupplier";
	}

	@GetMapping("/update/supplier")
	public String updateSupplierStatus(@RequestParam("supplier_id") String supplier_id, @RequestParam("status") String status) {
		adminService.updateStatusOfSupplier(supplier_id,status);
		return "redirect:/admin/pending/supplier";
	}
	
}
