package com.contra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.contra.entity.Amenities;
import com.contra.entity.Contract;
import com.contra.entity.Supplier;
import com.contra.entity.Terms;
import com.contra.service.AmenitiesService;
import com.contra.service.ContractService;
import com.contra.service.SupplierService;
import com.contra.service.TermService;

@Controller
@RequestMapping("/supplier/contract")
public class ContractController {

	@Autowired
	private SupplierService supplierService;
	
	@Autowired
	private ContractService contractService;

	@Autowired
	private TermService termService;

	@Autowired
	private AmenitiesService amenitiesService;

	private Supplier supplier = null;

	@GetMapping("/add")
	public String addContractForm(Model model) {
		Contract contract = new Contract();
		Amenities amenities = new Amenities();
		Terms terms = new Terms();
		model.addAttribute("contract", contract);
		model.addAttribute("terms", terms);
		model.addAttribute("amenities", amenities);
		return "addContract";
	}

	@PostMapping("/save")
	public String addContract(@ModelAttribute("contract") Contract contract, @ModelAttribute("terms") Terms terms,
			@ModelAttribute("amenities") Amenities amenities) {
		contractService.addContract(contract);
		termService.addTerms(terms,contract.getContract_id());
		amenitiesService.addAmenities(amenities,contract.getContract_id());
		return "redirect:/supplier/home";
	}
	
	@GetMapping("/view")
	public String viewContracts(@RequestParam("contract_id") int contract_id, Model model) {
		Contract contract = contractService.getContract(contract_id);
		Terms terms = termService.getTerm(contract_id);
		Amenities amenities = amenitiesService.getAmenity(contract_id);
		if (supplier == null) {
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name() + " " + supplier.getLast_name());
		model.addAttribute("contract", contract);
		model.addAttribute("terms", terms);
		model.addAttribute("amenities", amenities);
		return "viewContractSupplier";
	}
	
	@PostMapping("/updateContract")
	public String updateContract(@ModelAttribute("contract") Contract contract, @ModelAttribute("terms") Terms terms,
			@ModelAttribute("amenities") Amenities amenities) {
		contractService.updateContract(contract);
		termService.updateTerms(terms,contract.getContract_id());
		amenitiesService.updateAmenities(amenities,contract.getContract_id());
		return "redirect:/supplier/contract/view?contract_id="+contract.getContract_id();
	}
	
	@GetMapping("/modify")
	public String modifyContracts(Model model) {
		List<Contract> list = contractService.getAllContracts();
		if (supplier == null) {
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name() + " " + supplier.getLast_name());
		model.addAttribute("contracts", list);
		return "modifyContract";
	}
	
	@GetMapping("/delete")
	public String deleteContract(@RequestParam("contract_id") int contract_id,@RequestParam("url") String url) {
		contractService.deleteContract(contract_id);
		termService.deleteTerms(contract_id);
		amenitiesService.deleteAmenities(contract_id);
		return "redirect:"+url;
	}
	
	@GetMapping("/all")
	public String getAllContracts(Model model) {
		List<Contract> list = contractService.getAllContracts();
		if (supplier == null) {
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name() + " " + supplier.getLast_name());
		model.addAttribute("contracts", list);
		return "listContractSupplier";
	}

	@GetMapping("/accepted")
	public String getAllAcceptedContract(Model model) {
		List<Contract> list = contractService.getAllAcceptedContract();
		if (supplier == null) {
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name() + " " + supplier.getLast_name());
		model.addAttribute("contracts", list);
		return "acceptedContractSupplier";
	}

	@GetMapping("/pending")
	public String getAllPendingContract(Model model) {
		List<Contract> list = contractService.getAllPendingContract();
		if (supplier == null) {
			String username = supplierService.getUsername();
			supplier = supplierService.getUser(username);
		}
		model.addAttribute("admin", supplier.getFirst_name() + " " + supplier.getLast_name());
		model.addAttribute("contracts", list);
		return "pendingContractSupplier";
	}

}
