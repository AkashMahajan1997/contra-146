package com.contra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.contra.entity.Admin;
import com.contra.entity.Supplier;
import com.contra.service.AdminService;
import com.contra.service.SupplierService;

@Controller
@RequestMapping("/register")
public class RegisterController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private SupplierService supplierService;	
		
	@GetMapping("/admin")
	public String addAdminForm(@RequestParam(value="status",required = false) String status, Model model){		
		Admin admin=new Admin();
		if(status!=null){
			model.addAttribute("status", "Email already exist");
		}
		model.addAttribute("admin", admin);
		return "addAdmin";
	}
	
	
	@PostMapping("/addAdmin")
	public String addAdmin(@ModelAttribute("admin") Admin admin,Model model){
		try{
			adminService.addAdmin(admin);
			model.addAttribute("status", "1");
			return "redirect:/login";
		}
		catch(Exception exception){
			model.addAttribute("status", "0");
			return "redirect:/register/admin";
		}
	}
	
	@GetMapping("/supplier")
	public String showAddForm(@RequestParam(value="status",required = false) String status, Model model){
		Supplier supplier=new Supplier();
		if(status!=null){
			model.addAttribute("status", "Email already exist");
		}
		model.addAttribute("supplier", supplier);
		return "addSupplier";
		
	}
	

	@PostMapping("/addSupplier")
	public String addSupplier(@ModelAttribute("supplier")Supplier supplier,Model model){
		try{
			supplierService.addSupplier(supplier);
			model.addAttribute("status", "1");
			return "redirect:/login";
		}
		catch(Exception exception){
			model.addAttribute("status", "0");
			return "redirect:/register/supplier";
		}
	}
}
